<?php
session_start();

$dsn = 'mysql:dbname=teapla00_garage;host=teapla00.mysql.ukraine.com.ua';
$user = 'teapla00_garage';
$password = 'ywcjd7dx';

try {
    $dbh = new PDO($dsn, $user, $password,array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
  ));
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}


if(isset($_POST['data']) && isset($_SESSION['user_id']))
{
	$q = "UPDATE pages SET code = ? WHERE id = ?";
	$qr = $dbh->prepare($q);
	$qr->execute(array($_POST['data'], $_POST['id']));

	echo 'success';
}

if(isset($_POST['ur']))
{
	$name = $_POST['name'];
	$car = $_POST['car'];
	$review = $_POST['review'];
	$status = $_POST['status'];
	$date = $_POST['date'];
	$rate = $_POST['rate'];

	$q = "UPDATE reviews SET name = ?, car = ?, review = ?, status = ?, date = ?, rate = ? WHERE id = ?";
	$qr = $dbh->prepare($q);
	$qr->execute(array($name, $car, $review, $status,$date, $rate, $_POST['id']));

	echo 'success';
}